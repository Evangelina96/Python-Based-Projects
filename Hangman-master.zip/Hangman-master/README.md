# Hangman

This is my first interactive program: a playale simulation of a "Hangman" game, without the visual component.

Written in Python 3